===============================
Interim Patch for Bug: 21461025
===============================

Date: Jan 13, 2016
---------------------------------
Platform Patch for   : Linux x86-64
Product Patched      : Oracle HTTP Server
Product Version      : 11.1.1.9.0

This document describes how to install the interim patch for
bug # 21461025 . It includes the following sections:

        Section 1, "Prerequisites"

        Section 2, "Pre-Installation Instructions"

        Section 3, "Installation Instructions"

        Section 4, "Post-Installation Instructions"

        Section 5, "Deinstallation Instructions"

        Section 6, "Post Deinstallation Instructions"

        Section 7, "Bugs Fixed by This Patch"


1 Prerequisites
----------------

Ensure that you meet the following requirements before you install or
deinstall the patch:

1. Before applying the non-mandatory patches, ensure that you have the
   exact symptoms described in the bug.

2. Review and download the latest version of OPatch 11.1.x via Bug 6880880.
   (OPatch version 11.1.0.9.0 or higher)

    Patch : p6880880_111000_<PLATFORM>.zip

   a. Oracle recommends that all customers be on the latest version of OPatch.
      Review the My Oracle Support note 224346.1, and follow the instructions
      to update to the latest version if needed. Click the following link to
      view the note:

      Note 224346.1  - Opatch - Where Can I Find the Latest Version of Opatch?
      https://support.oracle.com/CSP/main/article?cmd=show&type=NOT&id=224346.1

   b. For FMW Opatch usage, refer to the document at:
      http://download.oracle.com/docs/cd/E21764_01/doc.1111/e16793/opatch.htm

3. Verify the OUI Inventory.
   OPatch needs access to a valid OUI inventory to apply patches.

   Note: This needs the ORACLE_HOME to be set(refer section "2. Pre-Installation Instructions")
   prior to run the below commands:

   Validate the OUI inventory with the following commands:

   $ opatch lsinventory

   If the command errors out, contact Oracle Support and work to validate
   and verify the inventory setup before proceeding.

4. Confirm the executables appear in your system PATH.

   The patching process will use the unzip and the OPatch executables. After
   setting the ORACLE_HOME environment, confirm if the following executables
   exist, before proceeding to the next step:

        - which opatch
        - which unzip

   If either of these executables do not show in the PATH, correct the
   problem before proceeding.

5. Create a location for storing the unzipped patch. This location
   will be referred to later in the document as PATCH_TOP.


2 Pre-Installation Instructions
-------------------------------

1. Set the ORACLE_HOME environment variable to Web Tier home.
   The default location is : "[MW_HOME]/Oracle_WT1"

2. Stop all servers (Admin Server and all Managed Server(s)).

3. Stop all opmn, OHS services.


3 Installation Instructions
---------------------------

Note: OPatch commands should be run with -jre option.
      Make sure the JDK version you use is the certified version for your product.

 e.g. opatch apply -jre $ORACLE_HOME/jdk/jre
        or
      opatch rollback -id <patch_id> -jre $ORACLE_HOME/jdk/jre

1. Unzip the patch zip file into the PATCH_TOP.

   $ unzip -d PATCH_TOP p21461025_111190_Linux-x86-64.zip

2. Set your current directory to the directory where the patch is located.

   $ cd PATCH_TOP/21461025

3. Run OPatch to apply the patch.

   $ opatch apply

When OPatch starts, it validates the patch and makes sure that there are no
conflicts with the software already installed in the ORACLE_HOME.
  OPatch categorizes two types of conflicts:

     a. Conflicts with a patch already applied to the ORACLE_HOME
        In this case, stop the patch installation, and contact Oracle Support
        Services.

     b. Conflicts with subset patch already applied to the ORACLE_HOME
        In this case, continue the install, as the new patch contains all the
        fixes from the existing patch in the ORACLE_HOME.


4 Post-Installation Instructions
---------------------------------

1. Start all opmn, OHS services.

2. Start all servers (Admin Server and all Managed Server(s)).


5 Deinstallation Instructions
------------------------------

If you experience any problems after installing this patch, remove the patch as
follows:

1. Make sure to follow the same Prerequisites or pre-install steps (if any)
   when deinstalling a patch.
   This includes setting up any environment variables like ORACLE_HOME and
   verifying the OUI inventory before deinstalling.

2. Change to the directory where the patch was unzipped.

   $ cd PATCH_TOP/21461025

3. Run OPatch to deinstall the patch.

   $ opatch rollback -id 21461025


6 Post Deinstallation Instructions
-----------------------------------

1. Restart all opmn, OHS services.

2. Restart all servers (Admin Server and all Managed Server(s)).


7 Bugs Fixed by This Patch
--------------------------

21461025 - TRACKING BUG FOR ORACLE HTTP SERVER (OHS) PLUGIN FOR 20324588

-----------------------------------------------------------------------------
DISCLAIMER:

This interim patch has only undergone basic unit testing, and has not been
through a complete test cycle generally followed for a production patch set.
Though the fixes in this document rectifies the bug, Oracle Corporation will
not be responsible for other issues that may arise due to these fixes.
Oracle Corporation recommends to later upgrade to the next production patch
set, when available. Applying this patch could overwrite other interim
patches applied since the last patch set. Customers need to make a request
to Oracle Support for a patch that includes those fixes, as well as inform
Oracle Support about all the patches installed when a Service Request is
opened. Please download, test, and provide feedback as soon as possible
to assist in the timely resolution of this problem.

Copyright (c) 2015, Oracle and/or its affiliates. All rights reserved.
-----------------------------------------------------------------------------

