==============================
One-off Patch for Bug:21663064
==============================

Date: Aug 20, 2015
------------------
Platform Patch for   : Linux x86-64
Product Patched      : Oracle HTTP Server
Product Version      : 11.1.1.9.0
-auto enabled        : No


Bugs Fixed by this patch:
-------------------------
20900385:FIX FOR BUG 20900385
21305938:FIX FOR BUG 21305938
21520649:FIX FOR BUG 21520649


Prerequisites:
--------------

1. Review and download the latest version of OPatch 11.1.x via Bug 6880880.
   (OPatch version 11.1.0.9.4)

   Oracle recommends that all customers be on the latest version of OPatch.
   Please review the following My Oracle Support note and follow the instructions
   to update to the latest version if needed:

   Note 224346.1  - Opatch - Where Can I Find the Latest Version of Opatch?

   NOTE: This is only required the first time the one off patch is applied
         or if there is a new opatch version available.

2. Verify the OUI Inventory.

   OPatch needs access to a valid OUI inventory to apply patches.
   Validate the OUI inventory with the following command:
   - opatch lsinventory

   If the command errors out, contact Oracle Support and work to validate
   and verify the inventory setup before proceeding.

3. Confirm executables appear in your system PATH.

   The patching process will use the unzip and the opatch executables. After
   setting the ORACLE_HOME environment, confirm both of these exist before
   continuing:

   - "which opatch"
   - "which unzip"

   If either of these executables do not show in the PATH, correct the problem
   before proceeding.

4. Create a location for storing the unzipped patch. This location
   will be referred to later in the document as PATCH_TOP.

5. This document is accurate at the time of release. For issues documented
   after the release of this SPU, see My Oracle Support Document 2037112.1
   Critical Patch Update October 2015 Oracle Fusion Middleware Known Issues

   Document My Oracle Support Note : 2037112.1 - Critical Patch Update October 2015 Oracle Fusion Middleware Known Issues


Pre Install Instructions:
-------------------------

- Set the ORACLE_HOME environment variable to where OHS is installed,
  e.g. [MW_HOME]/Oracle_WT1, [MW_HOME]/Oracle_FRHome1, or [MW_HOME]/Oracle_IDM1

Note: OHS may be installed in different Oracle homes depending on your installation.
Reference My Oracle Support Doc ID: 1591483.1  - "What is Installed in My Middleware or Oracle home?"

- Stop all opmn, OHS services.


Install Instructions:
---------------------

1. Unzip the patch zip file into the PATCH_TOP.

   unzip -d PATCH_TOP p21663064_111190_Linux-x86-64.zip

2. Set your current directory to the directory where the patch is located.
   cd PATCH_TOP/21663064

3. Run OPatch to apply the patch.

   Run following command:
   - opatch apply


When OPatch starts, it will validate the patch and make sure there
are no conflicts with the software already installed in the ORACLE_HOME.
OPatch categorizes two types of conflicts:

  (a) Conflicts with a patch already applied to the ORACLE_HOME
  In this case, please stop the patch installation and contact
  Oracle Support Services.

  (b) Conflicts with subset patch already applied to the ORACLE_HOME
  In this case, please continue the install, as the new patch
  contains all the fixes from the existing patch in the ORACLE_HOME.
  The subset patch will automatically be rolled back prior to the
  installation of the new patch.



Post Install Instructions:
--------------------------

-  Start all opmn, OHS services.


Deinstallation Instructions:
----------------------------

If you experience any problems after installing this patch, remove the patch as follows:

1. Make sure to follow the same Prerequisites or pre-install steps (if any) when deinstalling a patch.
   This includes setting up any environment variables like ORACLE_HOME and verifying the OUI inventory
   before deinstalling.

2. Change to the directory where the patch was unzipped.
   cd PATCH_TOP/21663064

3. Run OPatch to deinstall the patch.

   Run following command:
   - opatch rollback -id 21663064


Post Deinstallation Instructions:
---------------------------------

- Restart all opmn, OHS services.


DISCLAIMER:
===========
This one-off patch has undergone only basic unit testing. It has not been through the complete
test cycle that is generally followed for a production patch set. Though the fix in this one-off
patch rectifies the bug, Oracle Corporation will not be responsible for other issues that may arise
due to this fix. Oracle Corporation recommends that you upgrade to the next production patch set,
when it is available. Applying this one-off patch could overwrite other one-off patches applied
since the last patch set. Customers need to request Oracle Support for a patch that includes those
fixes as well as inform Oracle Support about all the PSE installed when an SR is opened.
Please download, test, and provide feedback as soon as possible to assist in the timely resolution
of this problem.
